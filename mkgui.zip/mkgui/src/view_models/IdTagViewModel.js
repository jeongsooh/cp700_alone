﻿/* global $, ko */
/* exported IdTagViewModel */

function IdTagResultViewModel(data)
{
  "use strict";
  var self = this;

  ko.mapping.fromJS(data, {}, self);
  // self.idtag = ko.observable(data.idtag);
  // self.expire = ko.observable(data.expire);
  // self.status = ko.observable(data.status);
}

function IdTagViewModel(baseEndpoint)
{
  "use strict";
  var self = this;
  var baseEndpoint = baseEndpoint;
  var endpoint = ko.pureComputed(function () { return baseEndpoint() + "/idtag"; });

  // Observable properties
  self.fetching = ko.observable(false);
  self.idtags = ko.mapping.fromJS([], {
    key: function(data) {
      return ko.utils.unwrapObservable(data.idtag);
    },
    create: function (options) {
      return new IdTagResultViewModel(options.data);
    }
  });

  self.update = function (after = function () { }) {
    self.fetching(true);
    $.get(endpoint(), function (data) {
      ko.mapping.fromJS(data, self.idtags);
    }, "json").always(function () {
      self.fetching(false);
      after();
    });
  };

  self.register = function() {
    if (confirm("카드등록 하시겠습니까 ?")) {
      $.post(baseEndpoint() + "/nfc", { mode: "register" }, function () {
      }).done(function(msg) {
        console.log(msg);
        if("OK" == msg) {
          self.update();
        }
        else {
          alert(msg);
        }
      }).fail(function () {
        alert("Failed to Register");
      }).always(function () {
      });
    }
  };

  self.clean = function () {
    if (confirm("등록된 모든 카드정보가 삭제됩니다. 정말로 삭제 하시겠습니까 ?")) {
      $.post(baseEndpoint() + "/nfc", { mode: "removeall" }, function () {
      }).done(function(msg) {
        console.log(msg);
        if("OK" == msg) {
          self.update();
        }
      }).fail(function () {
        alert("Failed to clean cache");
      }).always(function () {
      });
    }
  };

  self.remove = function (value) {
    if (confirm(value + " 카드를 삭제 하시겠습니까 ?")) {
      $.post(baseEndpoint() + "/nfc", { mode: "remove", idtag: value }, function () {
      }).done(function(msg) {
        console.log(msg);
        if("OK" == msg) {
          self.update();
        }
      }).fail(function () {
        alert("Failed to Remove");
      }).always(function () {
      });
    }
  };
}
