﻿/* global $, ko, ConfigViewModel, StatusViewModel, RapiViewModel, WiFiScanViewModel, WiFiConfigViewModel, OpenEvseViewModel, PasswordViewModel, ZonesViewModel, EnergyViewModel, IdTagViewModel, ConfigGroupViewModel */
/* exported OpenEvseWiFiViewModel */

function OpenEvseWiFiViewModel(baseHost, basePort, baseProtocol)
{
  "use strict";
  var self = this;

  self.baseHost = ko.observable("" !== baseHost ? baseHost : "openevse.local");
  self.basePort = ko.observable(basePort);
  self.baseProtocol = ko.observable(baseProtocol);

  self.baseEndpoint = ko.pureComputed(function () {
    var endpoint = "//" + self.baseHost();
    if(80 !== self.basePort()) {
      endpoint += ":"+self.basePort();
    }
    return endpoint;
  });

  self.wsEndpoint = ko.pureComputed(function () {
    var endpoint = "ws://" + self.baseHost();
    if("https:" === self.baseProtocol()){
      endpoint = "wss://" + self.baseHost();
    }
    if(80 !== self.basePort()) {
      endpoint += ":"+self.basePort();
    }
    endpoint += "/ws";
    return endpoint;
  });

  self.portalMode = ko.observable(false);
  self.config = new ConfigViewModel(self.baseEndpoint);
  self.status = new StatusViewModel(self.baseEndpoint);
  self.rapi = new RapiViewModel(self.baseEndpoint);
  self.scan = new WiFiScanViewModel(self.baseEndpoint);
  self.wifi = new WiFiConfigViewModel(self.baseEndpoint, self.config, self.status, self.scan, self.portalMode);
  self.openevse = new OpenEvseViewModel(self.baseEndpoint, self.config, self.status);
  self.zones = new ZonesViewModel(self.baseEndpoint);
  self.energy = new EnergyViewModel(self.baseEndpoint);
  self.card = new IdTagViewModel(self.baseEndpoint);

  self.initialised = ko.observable(false);
  self.updating = ko.observable(false);
  // self.scanUpdating = ko.observable(false);

  self.wifi.selectedNet.subscribe((net) => {
    if(false !== net) {
      self.config.ssid(net.ssid());
    }
  });

  self.config.ssid.subscribe((ssid) => {
    self.wifi.setSsid(ssid);
  });

  self.toggle = function (flag) {
    flag(!flag());
  };

  // schedule time source
  self.ScheduleEnable = ko.observable(false);
  self.ampmScheduleFrom = ko.observable(0);
  self.ampmScheduleTo = ko.observable(0);
  self.hourScheduleFrom = ko.observable(0);
  self.hourScheduleTo = ko.observable(0);

  self.status.schedule_enabled.subscribe((val) => {
      self.ScheduleEnable(val);
  });
  self.status.schedule_stime.subscribe((val) => {
    var time = self.status.schedule_stime();
    var ampm = Math.floor(time / 12);
    var hours = time % 12;    
    self.ampmScheduleFrom(ampm);
    self.hourScheduleFrom(hours);
  });
  self.status.schedule_etime.subscribe((val) => {
    var time = self.status.schedule_etime();
    var ampm = Math.floor(time / 12);
    var hours = time % 12;    
    self.ampmScheduleTo(ampm);
    self.hourScheduleTo(hours);      
  });

  function addZero(val) {
    return (val < 10 ? "0" : "") + val;
  }

  self.scheduleFrom = ko.pureComputed(function () {
    var time = self.status.schedule_stime();
    var ampm = Math.floor(time / 12);
    var hours = time % 12;
    return (ampm < 1 ? "오전 " : "오후 ") + addZero(hours ? hours : 12);
  });
  self.scheduleTo = ko.pureComputed(function () {
    var time = self.status.schedule_etime();
    var ampm = Math.floor(time / 12);
    var hours = time % 12;
    return (ampm < 1 ? "오전 " : "오후 ") + addZero(hours ? hours : 12);
  });

  // schedule time source
  self.scheduleFromAmPm = ko.computed({
    read: function() {
      return self.ampmScheduleFrom() == 1 ? "pm" : "am";
    },
    write: function(val) {
      switch(val)
      {
        case "am":
          self.ampmScheduleFrom(0);
          break;
        case "pm":
          self.ampmScheduleFrom(1);
          break;
      }
    }
  });
  self.scheduleFromHours = ko.computed({
    read: function() {
      return self.hourScheduleFrom();
    },
    write: function(val) {
      var hours = parseInt(val);
      self.hourScheduleFrom(hours);
    }
  });
  self.scheduleToAmPm = ko.computed({
    read: function() {
      return self.ampmScheduleTo() == 1 ? "pm" : "am";
    },
    write: function(val) {
      switch(val)
      {
        case "am":
          self.ampmScheduleTo(0);
          break;
        case "pm":
          self.ampmScheduleTo(1);
          break;
      }
    }
  });
  self.scheduleToHours = ko.computed({
    read: function() {
      return self.hourScheduleTo();
    },
    write: function(val) {
      var hours = parseInt(val);
      self.hourScheduleTo(hours);
    }
  });
  self.scheduleSource = ko.computed({
    read: function() {
      return self.ScheduleEnable() ? "dialy" : "none";
    },
    write: function(val) {
      switch(val)
      {
        case "none":
          self.ScheduleEnable(false);
          break;
        case "dialy":
          self.ScheduleEnable(true);
          break;
      }
    }
  });

  // -----------------------------------------------------------------------
  // Event: Set the schedule time
  // -----------------------------------------------------------------------
  self.setScheduleFetching = ko.observable(false);
  self.setScheduleSuccess = ko.observable(false);  
  self.setSchedule = function () {
    self.setScheduleFetching(true);
    self.setScheduleSuccess(false);

    var schedule = self.ScheduleEnable();
    var from = (self.ampmScheduleFrom() * 12) + self.hourScheduleFrom();
    var to = (self.ampmScheduleTo() * 12) + self.hourScheduleTo();
    var params = {
      schedule: schedule,
      stime: from,
      etime: to
    };

    $.post(self.baseEndpoint() + "/setschedule", params, function () {
      self.setScheduleFetching(false);
      self.setScheduleSuccess(true);
    }).done(function () {
      alert("예약충전 설정이 완료되었습니다.");
    }).fail(function () {
      self.setScheduleFetching(false);
      alert("예약충전 설정이 실패하였습니다.");
    }).always(function () {
      self.setScheduleFetching(false);
    });
  };

  // Authorize source
  self.AuthorizeEnable = ko.observable(true);
  self.status.authorize_enabled.subscribe((val) => {
      self.AuthorizeEnable(val);
  });

  self.authorizeSource = ko.computed({
    read: function() {
      return self.AuthorizeEnable() ? "card" : "cable";
    },
    write: function(val) {
      switch(val)
      {
        case "card":
          self.AuthorizeEnable(true);
          break;
        case "cable":
          self.AuthorizeEnable(false);
          break;
      }
    }
  });

  self.setAuthorizeFetching = ko.observable(false);
  self.setAuthorizeSuccess = ko.observable(false);  
  self.setAuthorize = function () {
    self.setAuthorizeFetching(true);
    self.setAuthorizeSuccess(false);

    var authorize = self.AuthorizeEnable();
    var params = {
      card: authorize
    };

    $.post(self.baseEndpoint() + "/setauthorize", params, function () {
      self.setAuthorizeSuccess(true);
    }).done(function () {
      alert("충전인증 설정이 완료되었습니다.");
    }).fail(function () {
      alert("충전인증 설정이 실패하였습니다.");
    }).always(function () {
      self.setAuthorizeFetching(false);
    });
  };


  // 5sec
  var updateTimer = null;
  var updateTime = 5 * 1000;

  // 3sec
  // var scanTimer = null;
  // var scanTime = 3 * 1000;

  // Get time update events
  self.status.time.subscribe((time) => {
    self.openevse.time.timeUpdate(new Date(time));
  });

  // Time source
  self.timeSource = ko.computed({
    read: function() {
      return self.config.sntp_enabled() ? "ntp" : (
        self.openevse.time.automaticTime() ? "browser" : "manual"
      );
    },
    write: function(val) {
      switch(val)
      {
        case "ntp":
          self.config.sntp_enabled(true);
          self.openevse.time.automaticTime(true);
          break;
        case "browser":
          self.config.sntp_enabled(false);
          self.openevse.time.automaticTime(true);
          break;
        case "manual":
          self.config.sntp_enabled(false);
          self.openevse.time.automaticTime(false);
          break;
      }
    }
  });

  self.time_zone = ko.computed({
    read: () => {
      return self.config.time_zone();
    },
    write: (val) => {
      if(undefined !== val && false === self.zones.fetching()) {
        self.config.time_zone(val);
      }
    }
  });

  // Tabs
  var tab = "status";
  if("" !== window.location.hash) {
    tab = window.location.hash.substr(1);
  }
  self.tab = ko.observable(tab);
  self.tab.subscribe(function (val) {
    window.location.hash = "#" + val;
  });
  self.isSystem = ko.pureComputed(function() { return "system" === self.tab(); });
  self.isServices = ko.pureComputed(function() { return "services" === self.tab(); });
  self.isStatus = ko.pureComputed(function() { return "status" === self.tab(); });
  self.isRapi = ko.pureComputed(function() { return "rapi" === self.tab(); });

  // Upgrade URL
  self.upgradeUrl = ko.observable("about:blank");

  // Show/hide password state
  self.wifiPassword = new PasswordViewModel(self.config.pass);
  self.wwwPassword = new PasswordViewModel(self.config.www_password);

  // -----------------------------------------------------------------------
  // Initialise the app
  // -----------------------------------------------------------------------
  self.loadedCount = ko.observable(0);
  self.itemsLoaded = ko.pureComputed(function () {
    return self.loadedCount() + self.openevse.updateCount();
  });
  self.itemsTotal = ko.observable(2 + self.openevse.updateTotal());
  self.start = function () {
    self.updating(true);
    self.status.update(function () {
      self.loadedCount(self.loadedCount() + 1);
      self.config.update(function () {
        self.loadedCount(self.loadedCount() + 1);
        // If we are accessing on a .local domain try and redirect
        if(self.baseHost().endsWith(".local") && "" !== self.status.ipaddress()) {
          if("" === self.config.www_username())
          {
            // Redirect to the IP internally
            self.baseHost(self.status.ipaddress());
          } else {
            window.location.replace("http://" + self.status.ipaddress() + ":" + self.basePort());
          }
        }
        if(self.status.rapi_connected()) {
          self.openevse.update(self.finishedStarting);
        } else {
          self.finishedStarting();
          self.status.rapi_connected.subscribe((val) => {
            if(val) {
              self.config.update(() => {
                self.openevse.update(() => {
                });
              });
            }
          });
        }
      });
      //self.connect();
    });
  };

  self.finishedStarting = function () {
    self.initialised(true);
    updateTimer = setTimeout(self.update, updateTime);

    // Load the upgrade frame
    self.upgradeUrl(self.baseEndpoint() + "/update");

    // Load the images
    var imgDefer = document.getElementsByTagName("img");
    for (var i=0; i<imgDefer.length; i++) {
      if(imgDefer[i].getAttribute("data-src")) {
        imgDefer[i].setAttribute("src", imgDefer[i].getAttribute("data-src"));
      }
    }

    // Load ChargePlus IdTag history Information
    self.card.update(() => {
    });
    // Load ChargePlus Energy history Information
    self.energy.update(() => {
    });

    // Load the Time Zone information
    if(false !== self.config.time_zone()) {
      self.zones.initialValue(self.config.time_zone());
      self.zones.update(() => {
        self.config.time_zone.valueHasMutated();
      });
    }

    self.updating(false);
  };

  // -----------------------------------------------------------------------
  // Get the updated state from the ESP
  // -----------------------------------------------------------------------
  self.update = function () {
    if (self.updating()) {
      return;
    }
    self.updating(true);
    if (null !== updateTimer) {
      clearTimeout(updateTimer);
      updateTimer = null;
    }
    self.status.update(function () {
      updateTimer = setTimeout(self.update, updateTime);
      self.updating(false);
    });
  };

  // -----------------------------------------------------------------------
  // WiFi scan update
  // -----------------------------------------------------------------------
  // var scanEnabled = false;
  // self.startScan = function () {
  //   if (self.scanUpdating()) {
  //     return;
  //   }
  //   scanEnabled = true;
  //   self.scanUpdating(true);
  //   if (null !== scanTimer) {
  //     clearTimeout(scanTimer);
  //     scanTimer = null;
  //   }
  //   self.scan.update(function () {
  //     if(scanEnabled) {
  //       scanTimer = setTimeout(self.startScan, scanTime);
  //     }
  //     self.scanUpdating(false);
  //   });
  // };
  // 
  // self.stopScan = function() {
  //   scanEnabled = false;
  //   if (self.scanUpdating()) {
  //     return;
  //   }
  // 
  //   if (null !== scanTimer) {
  //     clearTimeout(scanTimer);
  //     scanTimer = null;
  //   }
  // };

  self.wifiConnecting = ko.observable(false);
  self.status.mode.subscribe(function (newValue) {
    if(newValue === "STA+AP" || newValue === "STA") {
      self.wifiConnecting(false);
    }
    // if(newValue === "STA+AP" || newValue === "AP") {
    //   self.startScan();
    // } else {
    //   self.stopScan();
    // }
  });

  // -----------------------------------------------------------------------
  // Event: WiFi Connect
  // -----------------------------------------------------------------------
  self.saveNetworkFetching = ko.observable(false);
  self.saveNetworkSuccess = ko.observable(false);
  self.saveNetwork = function () {
    if (self.config.ssid() === "") {
      alert("Please select network");
    } else {
      self.saveNetworkFetching(true);
      self.saveNetworkSuccess(false);
      $.post(self.baseEndpoint() + "/savenetwork", { ssid: self.config.ssid(), pass: self.config.pass() }, function () {
        self.saveNetworkSuccess(true);
        self.wifiConnecting(true);
      }).done(function(msg) {
        console.log(msg);
        if("OK" != msg) {
          alert(msg);
        }
      }).fail(function () {
        alert("Failed to save WiFi config");
      }).always(function () {
        self.saveNetworkFetching(false);
      });
    }
  };

  // -----------------------------------------------------------------------
  // Event: Admin save
  // -----------------------------------------------------------------------
  self.saveAdminFetching = ko.observable(false);
  self.saveAdminSuccess = ko.observable(false);
  self.saveAdmin = function () {
    self.saveAdminFetching(true);
    self.saveAdminSuccess(false);
    $.post(self.baseEndpoint() + "/saveadmin", { user: self.config.www_username(), pass: self.config.www_password() }, function () {
      self.saveAdminSuccess(true);
    }).fail(function () {
      alert("Failed to save Admin config");
    }).always(function () {
      self.saveAdminFetching(false);
    });
  };

  // -----------------------------------------------------------------------
  // Event: Advanced save
  // -----------------------------------------------------------------------
  self.advancedGroup = new ConfigGroupViewModel(self.baseEndpoint, () => {
    return {
      hostname: self.config.hostname(),
      sntp_hostname: self.config.sntp_hostname()
    };
  }).done(() => {
    if (confirm("본 변경 사항을 적용하려면 재부팅해야합니다. 지금 재시작 하시겠습니까 ?")) {
      $.post(self.baseEndpoint() + "/restart", { }, function () {
        setTimeout(() => {
          var newLocation = "http://" + self.config.hostname() + ".local";
          if(80 != self.basePort()) {
            newLocation += ":" + self.basePort();
          }
          newLocation += "/";
          window.location.replace(newLocation);
        }, 5*1000);
      }).fail(function () {
        alert("Failed to restart");
      });
    }
  });

  // -----------------------------------------------------------------------
  // Event: OCPP save
  // -----------------------------------------------------------------------
  self.saveOcppFetching = ko.observable(false);
  self.saveOcppSuccess = ko.observable(false);
  self.saveOcpp = function () {
    var ocpp = {
      server: self.config.ocpp_server(),
      node: self.config.ocpp_node(),
      port: self.config.ocpp_port(),
      csid: self.config.ocpp_csid(),
      userid: self.config.ocpp_username(),
      password: self.config.ocpp_password(),
    };

    if (ocpp.server === "" || ocpp.node === "") {  //} || ocpp.csid === "") {
      alert("Please enter OCPP server config informtion");
    } else {
      self.saveOcppFetching(true);
      self.saveOcppSuccess(false);
      $.post(self.baseEndpoint() + "/saveocpp", ocpp, function () {
        self.saveOcppSuccess(true);
      }).fail(function () {
        alert("Failed to save OCPP config");
      }).always(function () {
        alert("OCPP setup is complete.");
        self.saveOcppFetching(false);
      });
    }
  };

  // -----------------------------------------------------------------------
  // Event: Set the time
  // -----------------------------------------------------------------------
  self.setTimeFetching = ko.observable(false);
  self.setTimeSuccess = ko.observable(false);
  self.setTime = function () {
    self.setTimeFetching(true);
    self.setTimeSuccess(false);

    var newTime = self.openevse.time.automaticTime() ? new Date() : self.openevse.time.evseTimedate();
    if(false == self.status.time())
    {
      self.openevse.openevse.time((date,valid=true) => {
        self.setTimeFetching(false);
        self.setTimeSuccess(valid);

        self.openevse.time.timeUpdate(date, valid);
      }, newTime);
    } else {
      var sntp = self.config.sntp_enabled();

      var params = {
        ntp: sntp,
        tz: self.time_zone()
      };
      if(false === sntp) {
        params.time = newTime.toISOString();
      }

      $.post(self.baseEndpoint() + "/settime", params, () => {
        self.setTimeFetching(false);
        self.setTimeSuccess(true);
      }).fail(() => {
        alert("Failed to set time");
        self.setTimeFetching(false);
      });
    }
  };

  // -----------------------------------------------------------------------
  // Event: Turn off Access Point
  // -----------------------------------------------------------------------
  self.turnOffAccessPointFetching = ko.observable(false);
  self.turnOffAccessPointSuccess = ko.observable(false);
  self.turnOffAccessPoint = function () {
    self.turnOffAccessPointFetching(true);
    self.turnOffAccessPointSuccess(false);
    $.post(self.baseEndpoint() + "/apoff", {
    }, function (data) {
      console.log(data);
      if (self.status.ipaddress() !== "") {
        setTimeout(function () {
          window.location = "http://" + self.status.ipaddress();
          self.turnOffAccessPointSuccess(true);
        }, 3000);
      } else {
        self.turnOffAccessPointSuccess(true);
      }
    }).fail(function () {
      alert("Failed to turn off Access Point");
    }).always(function () {
      self.turnOffAccessPointFetching(false);
    });
  };

  // -----------------------------------------------------------------------
  // Event: Reset config and reboot
  // -----------------------------------------------------------------------
  self.factoryResetFetching = ko.observable(false);
  self.factoryResetSuccess = ko.observable(false);
  self.factoryReset = function() {
    if (confirm("주의: 모든 설정 및 구성이 손실됩니다. 정말로 공장 초기화를 하시겠습니까 ?")) {
      self.factoryResetFetching(true);
      self.factoryResetSuccess(false);
      $.post(self.baseEndpoint() + "/reset", { }, function () {
        self.factoryResetSuccess(true);
      }).fail(function () {
        alert("Failed to Factory Reset");
      }).always(function () {
        self.factoryResetFetching(false);
      });
    }
  };


  // -----------------------------------------------------------------------
  // Event: Restart
  // -----------------------------------------------------------------------
  self.restartFetching = ko.observable(false);
  self.restartSuccess = ko.observable(false);
  self.restart = function() {
    if (confirm("장치를 다시 시작 하시겠습니까 ?")) {
      self.restartFetching(true);
      self.restartSuccess(false);
      $.post(self.baseEndpoint() + "/restart", { }, function () {
        self.restartSuccess(true);
      }).fail(function () {
        alert("Failed to restart");
      }).always(function () {
        self.restartFetching(false);
      });
    }
  };

  // -----------------------------------------------------------------------
  // Event: LTE reset
  // -----------------------------------------------------------------------
  self.resetModem = function () {
    $.post(self.baseEndpoint() + "/ltereset", { }, function () {
    }).fail(function () {
      alert("Failed to reset LTE");
    }).always(function () {
    });
  };

  // -----------------------------------------------------------------------
  // Event: Update
  // -----------------------------------------------------------------------

  // Support for OTA update of the OpenEVSE
  self.updateFetching = ko.observable(false);
  self.updateComplete = ko.observable(false);
  self.updateError = ko.observable("");
  self.updateFilename = ko.observable("");
  self.updateLoaded = ko.observable(0);
  self.updateTotal = ko.observable(1);
  self.updateProgress = ko.pureComputed(function () {
    return (self.updateLoaded() / self.updateTotal()) * 100;
  });

  self.otaUpdate = function () {
    self.updateFetching(true);
    self.updateError("");

    $.post(self.baseEndpoint() + "/ota", { }, function () {
    }).fail(function () {
      self.updateError("HTTP 업데이트 실패했습니다.");
    }).done(function(msg) {
      console.log(msg);
      if("OK" == msg) {
        self.updateComplete(true);
      } else {
        self.updateError(msg);
      }      
    }).always(function () {
      self.updateFetching(false);
    });
  };

  self.otaUpdateFile = function() {
    if("" === self.updateFilename()) {
      self.updateError("펌웨어 파일이 설정되지 않았습니다.");
      return;
    }

    self.updateFetching(true);
    self.updateError("");

    var form = $("#update_form")[0];
    var data = new FormData(form);

    $.ajax({
      url: "/update",
      type: "POST",
      data: data,
      contentType: false,
      processData:false,
      xhr: function() {
        var xhr = new window.XMLHttpRequest();
        xhr.upload.addEventListener("progress", function(evt) {
          if (evt.lengthComputable) {
            self.updateLoaded(evt.loaded);
            self.updateTotal(evt.total);
          }
        }, false);
        return xhr;
      }
    }).done(function(msg) {
      console.log(msg);
      if("OK" == msg) {
        self.updateComplete(true);
      } else {
        self.updateError(msg);
      }
    }).fail(function () {
      self.updateError("HTTP 업데이트 실패했습니다.");
    }).always(function () {
      self.updateFetching(false);
    });
  };

// -----------------------------------------------------------------------
  // Event: Upload
  // -----------------------------------------------------------------------

  // Support for file upload of the OpenEVSE
  self.uploadFetching = ko.observable(false);
  self.uploadComplete = ko.observable(false);
  self.uploadError = ko.observable("");
  self.uploadFilename = ko.observable("");
  self.uploadLoaded = ko.observable(0);
  self.uploadTotal = ko.observable(1);
  self.uploadProgress = ko.pureComputed(function () {
    return (self.uploadLoaded() / self.uploadTotal()) * 100;
  });

  self.fileUpload = function() {
    if("" === self.uploadFilename()) {
      self.uploadError("파일이 선택되지 않았습니다.");
      return;
    }

    self.uploadFetching(true);
    self.uploadError("");

    var form = $("#upload_form")[0];
    var data = new FormData(form);

    $.ajax({
      url: "/upload",
      type: "POST",
      data: data,
      contentType: false,
      processData:false,
      xhr: function() {
        var xhr = new window.XMLHttpRequest();
        xhr.upload.addEventListener("progress", function(evt) {
          if (evt.lengthComputable) {
            self.uploadLoaded(evt.loaded);
            self.uploadTotal(evt.total);
          }
        }, false);
        return xhr;
      }
    }).done(function(msg) {
      console.log(msg);
      if("OK" == msg) {
        self.uploadComplete(true);
      } else {
        self.uploadError(msg);
      }
    }).fail(function () {
      self.uploadError("파일 업로드를 실패했습니다.");
    }).always(function () {
      self.uploadFetching(false);
    });
  };

  // -----------------------------------------------------------------------
  // Receive events from the server
  // -----------------------------------------------------------------------
/*
  self.pingInterval = false;
  self.reconnectInterval = false;
  self.socket = false;
  self.connect = function () {
    self.socket = new WebSocket(self.wsEndpoint());
    self.socket.onopen = function (ev) {
      console.log(ev);
      self.pingInterval = setInterval(function () {
        self.socket.send("{\"ping\":1}");
      }, 1000);
    };
    self.socket.onclose = function (ev) {
      console.log(ev);
      self.reconnect();
    };
    self.socket.onmessage = function (msg) {
      console.log(msg);
      ko.mapping.fromJSON(msg.data, self.status);
    };
    self.socket.onerror = function (ev) {
      console.log(ev);
      self.socket.close();
      self.reconnect();
    };
  };
  self.reconnect = function() {
    if(false !== self.pingInterval) {
      clearInterval(self.pingInterval);
      self.pingInterval = false;
    }
    if(false === self.reconnectInterval) {
      self.reconnectInterval = setTimeout(function () {
        self.reconnectInterval = false;
        self.connect();
      }, 500);
    }
  };
*/
  // Cookie management, based on https://www.w3schools.com/js/js_cookies.asp
  self.setCookie = function (cname, cvalue, exdays = false) {
    var expires = "";
    if(false !== exdays) {
      var d = new Date();
      d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
      expires = ";expires="+d.toUTCString();
    }
    document.cookie = cname + "=" + cvalue + expires + ";path=/";
  };

  self.getCookie = function (cname, def = "") {
    var name = cname + "=";
    var ca = document.cookie.split(";");
    for(var i = 0; i < ca.length; i++) {
      var c = ca[i];
      while (c.charAt(0) === " ") {
        c = c.substring(1);
      }
      if (c.indexOf(name) === 0) {
        return c.substring(name.length, c.length);
      }
    }
    return def;
  };
}
