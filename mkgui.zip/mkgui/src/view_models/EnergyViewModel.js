﻿/* global $, ko */
/* exported EnergyViewModel */

function EnergyResultViewModel(data)
{
  "use strict";
  var self = this;

  ko.mapping.fromJS(data, {}, self);
//  self.name = ko.observable(data.datetime);
//  self.value = ko.observable(data.energy + " Wh");
//  // += parseFloat(data.energy);
}

function EnergyViewModel(baseEndpoint)
{
  "use strict";
  var self = this;
  var baseEndpoint = baseEndpoint;
  var endpoint = ko.pureComputed(function () { return baseEndpoint() + "/energy"; });

  // Observable properties
  self.fetching = ko.observable(false);
  self.energys = ko.mapping.fromJS([], {
    key: function(data) {
      return ko.utils.unwrapObservable(data.stime);
    },
    create: function (options) {
      return new EnergyResultViewModel(options.data);
    }
  });

  self.update = function (after = function () { }) {
    self.fetching(true);
    $.get(endpoint(), function (data) {
      if(data.length > 0) {
        ko.mapping.fromJS(data, self.energys);
      }
    }, "json").always(function () {
      self.fetching(false);
      after();
    });
  };
}