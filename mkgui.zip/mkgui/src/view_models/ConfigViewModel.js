﻿/* global $, ko, BaseViewModel */
/* exported ConfigViewModel */

function ConfigViewModel(baseEndpoint) {
  "use strict";
  var endpoint = ko.pureComputed(function () { return baseEndpoint() + "/config"; });
  BaseViewModel.call(this, {
    "ssid": "",
    "pass": "",
    "eipaddr": "",
    "associated": "",
    "www_username": "",
    "www_password": "",
    "hostname": false,
    "sntp_enabled": false,
    "sntp_hostname": false,
    "ocpp_server": "",
    "ocpp_node": "",
    "ocpp_csid": "",
    "ocpp_port": 80,
    "ocpp_username": "",
    "ocpp_password": "",
    "model": "-",
    "firmware": "-",
    "protocol": "-",
    "espflash": 0,
    "scale": 1,
    "offset": 0,
    "version": "0.0.0",
    "time_zone": false,
    "serial_no":"-----"
  }, endpoint);

  function trim(prop, val) {
    if(val.trim() !== prop()) {
      prop(val.trim());
    }
  }

  this.ssid.subscribe((v) => { trim(this.ssid, v); });
  this.eipaddr.subscribe((v) => { trim(this.eipaddr, v); });
  this.associated.subscribe((v) => { trim(this.associated, v); });
  this.www_username.subscribe((v) => { trim(this.www_username, v); });
  this.hostname.subscribe((v) => { trim(this.hostname, v); });
  this.sntp_hostname.subscribe((v) => { trim(this.sntp_hostname, v); });
  this.ocpp_server.subscribe((v) => { trim(this.ocpp_server, v); });
  this.ocpp_node.subscribe((v) => { trim(this.ocpp_node, v); });
  this.ocpp_csid.subscribe((v) => { trim(this.ocpp_csid, v); });
  this.ocpp_username.subscribe((v) => { trim(this.ocpp_username, v); });
  this.ocpp_password.subscribe((v) => { trim(this.ocpp_password, v); });
}
ConfigViewModel.prototype = Object.create(BaseViewModel.prototype);
ConfigViewModel.prototype.constructor = ConfigViewModel;

ConfigViewModel.prototype.update = function (after = function () { }) {
  this.fetching(true);
  $.get(this.remoteUrl(), (data) => {
    ko.mapping.fromJS(data, this);
  }, "json").always(() => {
    this.fetching(false);
    after();
  });
};
