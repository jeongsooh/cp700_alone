﻿/* global $, ko */
/* exported WiFiConfigViewModel */

function WiFiConfigViewModel(baseEndpoint, config, status, scan, portal) {
  "use strict";
  var self = this;

  self.baseEndpoint = baseEndpoint;
  self.config = config;
  self.status = status;
  self.scan = scan;
  self.portal = portal;

  self.scanUpdating = ko.observable(false);

  self.selectedNet = ko.observable(false);
  self.bssid = ko.pureComputed({
    read: () => {
      return (false === self.selectedNet()) ? "" : self.selectedNet().bssid();
    },
    write: (bssid) => {
      for(var i = 0; i < self.scan.results().length; i++) {
        var net = self.scan.results()[i];
        if(bssid === net.bssid()) {
          self.selectedNet(net);
          return;
        }
      }
    }
  });
  self.select = function(item) {
    self.selectedNet(item);
  };

  self.setSsid = function(ssid)
  {
    if(false !== self.selectedNet() && ssid === self.selectedNet().ssid()) {
      return;
    }

    for(var i = 0; i < self.scan.filteredResults().length; i++) {
      var net = self.scan.filteredResults()[i];
      if(ssid === net.ssid()) {
        self.selectedNet(net);
        return;
      }
    }

    for(var i = 0; i < self.scan.results().length; i++) {
      var net = self.scan.results()[i];
      if(ssid === net.ssid()) {
        self.selectedNet(net);
        return;
      }
    }

    self.selectedNet(false);
  }

  // 3sec
  var scanTimer = null;
  var scanTime = 3 * 1000;

  // -----------------------------------------------------------------------
  // WiFi force scan update
  // -----------------------------------------------------------------------
  self.forceConfig = ko.observable(false);
  self.status.mode.subscribe(function (newValue) {
    if ("AP" === newValue || self.portal()) {
      self.forceConfig(true);
    }
  });

  // -----------------------------------------------------------------------
  // WiFi scan update
  // -----------------------------------------------------------------------
  var scanEnabled = false;
  self.startScan = function () {
    if (self.scanUpdating() || !self.forceConfig()) {
      return;
    }
    scanEnabled = true;
    self.scanUpdating(true);
    if (null !== scanTimer) {
      clearTimeout(scanTimer);
      scanTimer = null;
    }
    self.scan.update(function () {
      // if(scanEnabled) {
      //   scanTimer = setTimeout(self.startScan, scanTime);
      // }

      // if bssid is not set see if we have a ssid that matches our configured result
      if("" === self.bssid()) {
        var ssid = self.config.ssid();
        for(var i = 0; i < self.scan.results().length; i++) {
          var net = self.scan.results()[i];
          if(ssid === net.ssid()) {
            self.bssid(net.bssid());
            break;
          }
        }
      }

      self.scanUpdating(false);
      self.forceConfig(false);
    });
  };

  self.stopScan = function() {
    scanEnabled = false;
    if (self.scanUpdating()) {
      return;
    }

    if (null !== scanTimer) {
      clearTimeout(scanTimer);
      scanTimer = null;
    }
  };

  self.enableScan = function (enable) {
    if(enable) {
      self.startScan();
    } else {
      self.stopScan();
    }
  };

  self.canOcppConfigure = ko.pureComputed(function () {
    if ("" === self.config.ocpp_csid() || self.config.serial_no() == self.config.ocpp_csid()) {
      return true;
    }
    return false;
  });

  self.canConfigure = ko.pureComputed(function () {
    if(self.status.isWiFiError() || self.wifiConnecting() || self.status.isWired()) {
      return false;
    }

    return !self.status.isWifiClient() || self.forceConfig();
  });

  self.wifiConnecting = ko.observable(false);
  self.forceConfig.subscribe(function (newValue) {
    self.enableScan(newValue);
  });
  self.canConfigure.subscribe(function (newValue) {
    self.enableScan(newValue);
  });
  self.status.wifi_client_connected.subscribe(function (newValue) {
    if(newValue) {
      self.wifiConnecting(false);
    }
  });
  self.enableScan(self.canConfigure());

  // -----------------------------------------------------------------------
  // Event: WiFi Connect
  // -----------------------------------------------------------------------
  self.saveNetworkFetching = ko.observable(false);
  self.saveNetworkSuccess = ko.observable(false);
  self.saveNetwork = function () {
    if (self.config.ssid() === "") {
      alert("Please select network");
    } else {
      self.saveNetworkFetching(true);
      self.saveNetworkSuccess(false);
      $.post(self.baseEndpoint() + "/savenetwork", { ssid: self.config.ssid(), pass: self.config.pass() }, function () {
        // HACK: Almost certainly won't get a status update with client connected set to false so manually clear it here
        self.status.wifi_client_connected(false);

        // Done with setting the config
        self.forceConfig(false);

        // Wait for a new WiFi connection
        self.wifiConnecting(true);

        // And indiccate the save was successful
        self.saveNetworkSuccess(true);
      }).fail(function () {
        alert("Failed to save WiFi config");
      }).done(function(msg) {
        console.log(msg);
        if("OK" != msg) {
          alert(msg);
        }
      }).always(function () {
        self.saveNetworkFetching(false);
      });
    }
  };

  // -----------------------------------------------------------------------
  // Event: Turn off Access Point
  // -----------------------------------------------------------------------
  self.turnOffAccessPointFetching = ko.observable(false);
  self.turnOffAccessPointSuccess = ko.observable(false);
  self.turnOffAccessPoint = function () {
    self.turnOffAccessPointFetching(true);
    self.turnOffAccessPointSuccess(false);
    $.post(self.baseEndpoint() + "/apoff", {
    }, function (data) {
      console.log(data);
      if (self.status.ipaddress() !== "") {
        setTimeout(function () {
          window.location = "//" + self.status.ipaddress();
          self.turnOffAccessPointSuccess(true);
        }, 3000);
      } else {
        self.turnOffAccessPointSuccess(true);
      }
    }).fail(function () {
      alert("Failed to turn off Access Point");
    }).always(function () {
      self.turnOffAccessPointFetching(false);
    });
  };

  // -----------------------------------------------------------------------
  // Event: OCPP save
  // -----------------------------------------------------------------------
  self.saveOcppFetching = ko.observable(false);
  self.saveOcppSuccess = ko.observable(false);
  self.saveOcpp = function () {
    var ocpp = {
      server: self.config.ocpp_server(),
      node: self.config.ocpp_node(),
      port: self.config.ocpp_port(),
      csid: self.config.ocpp_csid(),
      userid: self.config.ocpp_username(),
      password: self.config.ocpp_password(),
    };

    if (ocpp.server === "" || ocpp.node === "") {  //} || ocpp.csid === "") {
      alert("Please enter OCPP server config informtion");
    } else {
      self.saveOcppFetching(true);
      self.saveOcppSuccess(false);
      $.post(self.baseEndpoint() + "/saveocpp", ocpp, function () {
        self.saveOcppSuccess(true);
      }).fail(function () {
        alert("Failed to save OCPP config");
      }).always(function () {
        alert("OCPP setup is complete.");        
        self.saveOcppFetching(false);
      });
    }
  };
}
