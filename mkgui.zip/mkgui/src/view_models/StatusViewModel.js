﻿/* global ko, BaseViewModel */

function StatusViewModel(baseEndpoint) {
  "use strict";
  var self = this;
  var endpoint = ko.pureComputed(function () { return baseEndpoint() + "/status"; });

  function addZero(val) {
    return (val < 10 ? "0" : "") + val;
  }

  BaseViewModel.call(self, {
    "mode": "ERR",
    "wifi_client_connected": 0,
    "eth_connected": 0,
    "net_connected": 0,
    "srssi": "",
    "ipaddress": "",
    "packets_sent": 0,
    "packets_success": 0,
    "free_heap": 0,
    "comm_sent": 0,
    "comm_success": 0,
    "rapi_connected": true,
    "amp": 0,
    "voltage": 0,
    "pilot": 0,
    "temp1": 0,
    "temp2": 0,
    "state": 0,
    "elapsed": 0,
    "wattsec": 0,
    "watthour": 0,
    "ota_update": false,
    "time": false,
    "offset": false,
    "watt": 0,
    "powerfactor": 0,
    "authorize_enabled": 0,
    "schedule_enabled": 0,
    "schedule_stime": 22,
    "schedule_etime": 8,
    "bugresponse": "none"
  }, endpoint);

  // Some devired values
  self.isWiFiError = ko.pureComputed(function () {
    return ("ERR" === self.mode());
  });
  self.isWifiClient = ko.pureComputed(function () {
    return ("STA" === self.mode()) || ("STA+AP" === self.mode());
  });
  self.isWifiAccessPoint = ko.pureComputed(function () {
    return ("AP" === self.mode()) || ("STA+AP" === self.mode());
  });
  self.isWired = ko.pureComputed(() => {
    return ("Wired" === self.mode());
  });
  self.fullMode = ko.pureComputed(function () {
    switch (self.mode()) {
      case "AP":
        return "Access Point (AP)";
      case "STA":
        return "Client (STA)";
      case "STA+AP":
        return "Client + Access Point (STA+AP)";
      case "Wired":
        return "Wired Ethernet";
    }

    return "Unknown (" + self.mode() + ")";
  });

  self.elapsedNow = ko.observable(new Date(0));
  self.elapsed.subscribe(function (val) {
    self.elapsedNow(new Date(val * 1000));
  });

  this.nowelapsed = ko.pureComputed(function () {
    var time = self.elapsedNow().getTime();
    time = Math.floor(time / 1000);
    var seconds = time % 60;
    time = Math.floor(time / 60);
    var minutes = time % 60;
    var hours = Math.floor(time / 60);
    return hours+":"+addZero(minutes)+":"+addZero(seconds);
  });

  this.estate = ko.pureComputed(function () {
    var estate;
    switch (self.state()) {
      case 0:
        estate = "준비중";
        break;
      case 1:
        estate = "Not Connected";
        break;
      case 2:
        estate = "충전대기";
        break;
      case 3:
        estate = "충전중";
        break;
      case 4:
        estate = "Vent Required";
        break;
      case 5:
        estate = "Diode Check Failed";
        break;
      case 6:
        estate = "GFCI Fault";
        break;
      case 7:
        estate = "No Earth Ground";
        break;
      case 8:
        estate = "Stuck Relay";
        break;
      case 9:
        estate = "GFCI Self Test Failed";
        break;
      case 10:
        estate = "Over Temperature";
        break;
      case 11:
        estate = "Over Current";
        break;
      case 254:
        estate = "Waiting";
        break;
      case 255:
        estate = "Disabled";
        break;
      default:
        estate = "Invalid";
        break;
    }
    return estate;
  });
}
StatusViewModel.prototype = Object.create(BaseViewModel.prototype);
StatusViewModel.prototype.constructor = StatusViewModel;
